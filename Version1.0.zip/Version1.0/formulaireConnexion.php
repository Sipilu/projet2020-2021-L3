<?php session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>Connexion</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>

    <body>
	
	<?php
    require_once('header.php');
	?>
		
	<div class="corpsAccueil">
	
	<?php
			try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=bddoutilcoach;charset=utf8', 'root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch (Exception $e)
		{
				die("Connection failed: " . mysqli_connect_error());
		}
		//  Récupération de l'utilisateur et de son pass hashé
		$pseudo = $_POST['pseudo'];
		$req = $bdd->prepare("SELECT id, password FROM coach WHERE pseudo = '$pseudo'");
		$req->execute(array(
			'pseudo' => $pseudo));
		$resultat = $req->fetch();

		// Comparaison du pass envoyé via le formulaire avec la base
		$ifPass_true = password_verify($_POST['password'], $resultat['password']);

		if (!$resultat)
		{
			echo '<p>Mauvais identifiant ou mot de passe !</p>';
			echo '<a href="pageAccueil.php"><p>Page d\'Accueil</p></a>';
		}
		else
		{
			if ($ifPass_true) {
				$_SESSION['id'] = $resultat['id'];
				$_SESSION['pseudo'] = $pseudo;
				echo '<p>Vous êtes connecté !</p>';
				echo '<a href="accueil.php"><h1>Page d\'Accueil</h1></a>';
				echo '<a href="Plan_compo_equipe.php"><h1>Plan compo équipe</h1></a>';
			}
			else {
				echo '<p>Mauvais identifiant ou mot de passe !</p>';
				echo '<a href="accueil.php"><h1>Page d\'Accueil</h1></a>';
			}
		}
		if (isset($_SESSION['id']) AND isset($_SESSION['pseudo']))
			{
				echo $_SESSION['id'] . $_SESSION['pseudo'];
			}
		?>
	</div>

	<?php
	require_once('footer.php');
	?>

	</body>
	
</html>