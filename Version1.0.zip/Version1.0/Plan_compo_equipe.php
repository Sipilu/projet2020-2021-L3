﻿<!DOCTYPE html>
 <?php session_start();
 include("formations.php");
 include("affichageJoueurs.php");
 include("connexionBDD.php");
 $conn = connexionBDD();
 $coach = $_SESSION['pseudo'];
 $i = 1;
 $result = affichageJoueur2();
$placementJoueur = NULL;

?>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<link  rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleFormulaireInscriptionConnexion.css"/>
		<link rel="icon" href="image/logo.png" />
		<title>Page Principal "Plan Composition d'Equipe"</title>
		<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
		<script type="text/javascript">
		
		
		function foot() {
			var terrain = "image/PlanCompoFoot.png"
			document.getElementById('choixterrain').style.backgroundImage = "url("+terrain+")";
		}
		function basket() {
			var terrain = "image/PlanCompoBasket.png"
			document.getElementById('choixterrain').style.backgroundImage = "url("+terrain+")";
		}
		function handball() {
			var terrain = "image/PlanCompoHandball.png"
			document.getElementById('choixterrain').style.backgroundImage = "url("+terrain+")";
		}

		function formAjout() {
			document.getElementById("myFormAjout").style.display = "block";
		}
		function closeFormAjout() {
			document.getElementById("myFormAjout").style.display = "none";
		}

		function formRemove() {
			document.getElementById("myFormRemove").style.display = "block";
		}
		function closeFormRemove() {
			document.getElementById("myFormRemove").style.display = "none";
		}


		function dragstart_handler(ev) {
		console.log("dragStart");
		// Change the source element's background color to signify drag has started
		//ev.currentTarget.style.border = "dashed";
		// Add the id of the drag source element to the drag data payload so
		// it is available when the drop event is fired
		ev.dataTransfer.setData("text", ev.target.id);
		// Tell the browser both copy and move are possible
		ev.effectAllowed = "copyMove";
		}

		function dragover_handler(ev) {
		console.log("dragOver");
		// Change the target element's border to signify a drag over event
		// has occurred
		//ev.currentTarget.style.background = "lightblue";
		ev.preventDefault();
		}

		function drop_handler_copy(ev) {
		console.log("Drop");
		ev.preventDefault();
		// Get the id of drag source element (that was added to the drag data
		// payload by the dragstart event handler)
		var id = ev.dataTransfer.getData("text");
		// Copy the element if the source and destination ids are both "copy" (that will always be true)
		var nodeCopy = document.getElementById(id).cloneNode(true);
		nodeCopy.id = "newId";
		ev.target.appendChild(nodeCopy);
		}

		function drop_handler(ev) {
		console.log("Drop");
		ev.preventDefault();
		// Get the id of drag source element (that was added to the drag data
		// payload by the dragstart event handler)
		var id = ev.dataTransfer.getData("text");
		// Only Move the element if the source and destination ids are both "move"
		ev.target.appendChild(document.getElementById(id));
		}

		function dragend_handler(ev) {
		console.log("dragEnd");
		// Restore source's border
		//ev.target.style.border = "solid black";
		// Remove all of the drag data
		ev.dataTransfer.clearData();
		}

		</script>

	<?php
	if(isset($_POST['inputHandball']))
	{
		$placementJoueur = formationHandballBase();
		$terrain = "handball";
	}
	if(isset($_POST['inputBasket']))
	{
		$placementJoueur = formationBasketBase();
		$terrain = "basket";
	}
	if(isset($_POST['inputFoot']))
	{
		$placementJoueur = formationFootBase();
		$terrain = "foot";
	}
	?>
	
	</head>

	<body>

	<?php
    require_once('header.php');
	?>
	
	<!--lien-->
	<div class="link">
		<a href="Plan_Tactique.php"><h1>Plan Tactique</h1></a>
		<a href="Plan_compo_equipe.php"><h1>Plan compo equipe</h1></a>
		<a href="Statistique.php"><h1>Edition joueur</h1></a>
		<a href="Classement.php"><h1>Classement</h1></a>
		<a href="mail.php"><h1>Convoquer</h1><a>
		<a class="open-button" onclick="formAjout();closeFormRemove()"><h1>Ajouter Joueur</h1></a>
		<a class="open-button" onclick="formRemove();closeFormAjout()"><h1>Retirer Joueur</h1></a>
	</div>
	
	<!--formAjout-->
	<div class="form-popup" id="myFormAjout">
		<form method="POST" class="formulaire2">
            <h1 class="titreFormulaire">Ajouter joueur</h1>

            <div>
				<label>Nom :</label>			
				<input class="champFormulaire" type="text" placeholder=" Entrer un nom" name="nom" required>
			</div>

            <div>		
				<label>Prenom :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un prénom" name="prenom" required>
            </div>

            <div>
				<label>Age :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un age" name="age" required>
            </div>

            <div>
				<label>Taille :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer une taille" name="taille" required>
            </div>

            <div>	
				<label>Poids :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un poids" name="poids" required>
            </div>

            <div>
				<label>VMA :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer une VMA" name="vma" required>
            </div>

            <div>
				<label>Email :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un email" name="email" required>
            </div>	

			<div>
				<button type="submit" class="btn ouvrir" onClick="closeFormAjout()">Confirmer</button>
				<button type="button" class="btn fermer" onClick="closeFormAjout()">Fermer</button>
			</div>

		</form>
	</div>
	
	<!--formRemove-->
	<div class="form-popup" id="myFormRemove">
		<form method="POST" class="formulaire2">
			<h1 class="titreFormulaire">Retirer joueur</h1>

			<div>
				<label>Nom :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un nom" name="nom" required>
			</div>

			<div>
				<label>Prenom :</label>
				<input class="champFormulaire" type="text" placeholder=" Entrer un prénom" name="prenom" required>
			</div>

			<div>
				<button type="submit" class="btn ouvrir" onClick="closeFormRemove()">Confirmer</button>
				<button type="button" class="btn fermer" onClick="closeFormRemove()">Fermer</button>
			</div>
		</form>
	</div>

	


		<?php

		if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['age']) and !empty($_POST['taille']) and !empty($_POST['poids']) and !empty($_POST['vma']))
		
		{
			$nom = $_POST['nom'];
			$prenom = $_POST['prenom'];
			$age = $_POST['age'];
			$taille = $_POST['taille'];
			$poids = $_POST['poids'];
			$vma = $_POST['vma'];
			$email = $_POST['email'];
			$result = "";

			// On vérifie que la data n'est pas deja dans la database
			$reponse1000 = $conn->prepare("SELECT nom, prenom FROM joueur WHERE nom='$nom' AND prenom='$prenom';");
			$reponse1000->execute();
			$nbrows1 = $reponse1000->rowCount();
			if($nbrows1 == 0) // Validé si nom et prenom n'existe pas dans la database
				{
					$reponse1001 = $conn->prepare("INSERT INTO joueur (coach,nom,prenom,age,taille,poids,vma,email) VALUES ('$coach','$nom','$prenom','$age','$taille','$poids','$vma','$email');");
					$reponse1001->execute();
					$nbrows2 = $reponse1001->rowCount();
					if ($nbrows2 > 0) 
					{  		// Juste pour savoir s'il y a au moins 1 joueur
					//   while($ligne = $reponse1001->fetch(PDO::FETCH_OBJ)) 	// $ligne prend les infos de 1 joueur a chaque itération
					  // {
						/*	$nom = htmlentities($ligne->nom);
							$prenom = htmlentities($ligne->prenom);
							$age = htmlentities($ligne->age);
							$taille = htmlentities($ligne->taille);
							$poids = htmlentities($ligne->poids);
							$vma = htmlentities($ligne->vma);*/
							$result = affichageJoueur2();
					//	}
					}
				//	return $result;
				}
		}

		if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['remove']))

		{
			$nom = $_POST['nom'];
			$prenom = $_POST['prenom'];
			$remove = $_POST['remove'];

			// On vérifie que la data est dans la database
			$reponse1002 = $conn->prepare("SELECT nom, prenom FROM joueur WHERE nom='$nom' AND prenom='$prenom';");
			$reponse1002->execute();
			$nbrows1 = $reponse1002->rowCount();
			if($nbrows1 == 1) // Validé si nom et prenom existe pas dans la database
				{
					$reponse1003 = $conn->prepare("DELETE FROM joueur WHERE coach = '$coach' AND nom = '$nom' AND prenom = '$prenom';");
					$reponse1003->execute();
					$nbrows2 = $reponse1003->rowCount();
					if ($nbrows2 > 0) 
					{ 
							$result = affichageJoueur2();
					}
				}
		}


		?>

		<nav>
			<ul>
				<li class="deroulant">
					<a href="#">Type de terrain &ensp;</a>
					<ul class="sous">
						<li><form method="post"><input class="boutonTerrain" type="submit" name="inputHandball" value="Handball"></input></form></li>
						<li><form method="post"><input class="boutonTerrain" type="submit" name="inputBasket" value="Basket"></input></form></li>
						<li><form method="post"><input class="boutonTerrain" type="submit" name="inputFoot" value="Football"></input></form></li>
					</ul>
				</li>
			</ul>
		</nav>
		
	
	<div class="flexzone">
		<div class="terrain" id="choixterrain"> <?php echo $placementJoueur; ?> </div>


		<!-- PARTIE PERMETTANT LE SCREEN DU TERRAIN -->
		<input type='button' id='but_screenshot' value='Take screenshot' onclick='screenshot();'><br/>

		<!-- Script -->
		<script type="text/javascript" src="html2canvas-master/dist/html2canvas.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

		<script type='text/javascript'>
		function screenshot(){
			html2canvas(document.getElementById('choixterrain')).then(function(canvas) {

		//	document.body.appendChild(canvas);

			// Get base64URL
			var base64URL = canvas.toDataURL('image/jpeg').replace('image/jpeg', 'image/octet-stream');

			// AJAX request
			$.ajax({
			url: 'screenshotTerrain.php',
			type: 'post',
			data: {image: base64URL},
			success: function(data){
				console.log('Upload successfully');
			}
			});
		});  
		}
		</script>

		<?php
		//bouton de Reset les positions
		if(!empty($placementJoueur))// alors terrain d'afficher, on peut afficher ce bouton
			{
				if($terrain == "handball")
					{
						echo "<form method=\"post\"><input class=\"btnReset\" type=\"submit\" name=\"inputHandball\" value=\"Reset les positions\"></input></form>";
					}
				if($terrain == "basket")
					{
						echo "<form method=\"post\"><input class=\"btnReset\" type=\"submit\" name=\"inputBasket\" value=\"Reset les positions\"></input></form>";
					}
				if($terrain == "foot")
					{
						echo "<form method=\"post\"><input class=\"btnReset\" type=\"submit\" name=\"inputFoot\" value=\"Reset les positions\"></input></form>";
					}
			}
		?>
		

		<div class="joueur" style="overflow-y:scroll;">
			<!--style="overflow-y:scroll; sert à pouvoir scroll le tableau si trop d'info sur l'axe vertical  -->
			<table>
				<tr>
					<th colspan="7"> Joueurs </th>
				</tr>
				<tr>
					<th> Nom </th>
					<th> Prenom </th>
					<th> Age </th>
					<th> Taille (m) </th>
					<th> Poids (kg) </th>
					<th> VMA (km/h) </th>
					<th> Jeton </th>
				</tr>
				<?php echo $result; ?>


			</table>
		</div>
	</div>

	<?php
	if(isset($_POST['inputFoot']))
	{
		echo '
		<script type="text/javascript">
		foot();
		</script>';
	}
	if(isset($_POST['inputBasket']))
	{
		echo '
		<script type="text/javascript">
		basket();
		</script>';
	}
	if(isset($_POST['inputHandball']))
	{
		echo '
		<script type="text/javascript">
		handball();
		</script>';
	}
	?>
	
	<?php
	require_once('footer.php');
	?>

	</body>

</html>
