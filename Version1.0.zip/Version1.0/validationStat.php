<?php session_start();
    $tirs = $_POST['tirs'];
    $points = $_POST['points'];
    $passes = $_POST['passes'];
    $passesValide = $_POST['passesValide'];
    $interceptions = $_POST['interceptions'];
    $fautes = $_POST['fautes'];

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];

    $servername = "localhost";
    $username = "root";
	$password = "";
	$dbname = "bddoutilcoach";
		try{
			$conn = new PDO('mysql:host='.$servername.';dbname='.$dbname,$username,$password);
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			}
		catch(PDOException $e)
    		{
    		echo "Connection failed: " . $e->getMessage();
			}
    if($conn)
        {
            $reponse1000 = $conn->exec("UPDATE joueur SET nbMatch = nbMatch + 1, tirs = tirs + '$tirs', points = points + '$points', passes = passes + '$passes', passesValide = passesValide + '$passesValide', interceptions = interceptions + '$interceptions', fautes = fautes + '$fautes' WHERE nom = '$nom' AND prenom = '$prenom';");
        }
?>
<!DOCTYPE html>
<html lang="en">

	<head>
	<meta charset="utf-8">
		<link  rel="stylesheet" href="style.css"/>
		<link rel="icon" href="image/logo.png" />
	<title>Page Principal "Statistique"</title>
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
	</head>

	<body>

    <?php
    require_once('header.php');
	?>

    <?php
        if($conn)
            {
                echo "<div> Les statistiques de $nom $prenom ont bien été modifier. </div>";
            }
        else
            {
                echo "<div> ERREUR Les statistiques de $nom $prenom n'ont pas bien été modifier. </div>";
            }
    ?>
    <a href="Statistique.php"> Refaire une modification d'un joueur </a> &nbsp 
    <a href="accueil.php"> Revenir a la page d'acceuil </a>

    <?php
	require_once('footer.php');
	?>

  </body>
  
</html>
