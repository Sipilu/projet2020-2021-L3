<?php session_start();
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleFormulaireInscriptionConnexion.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
        <title>Connexion</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>

    <body>
	
	<?php
    require_once('header.php');
	?>

	<div class="corps">

		<form class="formulaire" action="formulaireConnexion.php" method="post">
			<h1 class="titreFormulaire">Connexion</h1>
			
			<div>
			<label>Pseudo :</label>	
			<input class="champFormulaire" type="text" name="pseudo" placeholder=" pseudo" required />
			</div>

			<div>
			<label>mdp :</label>	
			<input class="champFormulaire" type="text" name="password" placeholder=" Mot de passe" required />
			</div>

			<div>
			<button class="boutonValidation bouton1" type="submit">Connexion</button>
			</div>	

			<p class="redirection"> Vous n'avez pas de compte ? <a href="inscription.php">Rendez vous sur cette page</a> mot de passe perdu ?<a href="###"> Recuperer mot de passe</a></p>
		</form>

	</div>

	<?php
	require_once('footer.php');
	?>
    
	</body>

</html>