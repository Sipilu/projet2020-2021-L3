<?php
function affichageJoueur1()
    {
        $conn = connexionBDD();
        $i = 1;

        
        $result="";
        $coach = $_SESSION['pseudo'];
        $reponse1002 = $conn->prepare("SELECT nom, prenom, age, taille, poids, vma FROM joueur WHERE coach = :coach ;");
        $reponse1002->bindParam(':coach',$coach);
        $reponse1002->execute();
        while($ligne = $reponse1002->fetch(PDO::FETCH_OBJ))
            {
                $mydiv = "mydiv".$i;	$i = $i + 1;
            //	echo $mydiv;
                $nom = htmlentities($ligne->nom);
                $prenom = htmlentities($ligne->prenom);
                $age = htmlentities($ligne->age);
                $taille = htmlentities($ligne->taille);
                $poids = htmlentities($ligne->poids);
                $vma = htmlentities($ligne->vma);

            //	echo "$nom $prenom $age $taille $poids $vma";
                $result = $result.
                    "<tr>
                        <th>".$nom."</th>
                        <th>".$prenom."</th>
                        <th>".$age."</th>
                        <th>".$taille."</th>
                        <th>".$poids."</th>
                        <th>".$vma."</th>
                        <th> <div class=\"draggable\" id=".$mydiv."> <div> ".$nom." ".$prenom." </div> <div onmousedown=\"positionAbs('".$mydiv."')\" dblclick=\"positionF('".$mydiv."')\"> <img src=\"image/jeton.png\" /> </div> </div> </th>
                    </tr>";
            }
        $result = $result."!".$i;
        return $result;
    }

function affichageJoueur2()
    {
        $conn = connexionBDD();
        $i = 1;

        $result="";
        $coach = $_SESSION['pseudo'];
        $reponse1002 = $conn->prepare("SELECT nom, prenom, age, taille, poids, vma FROM joueur WHERE coach = :coach ;");
        $reponse1002->bindParam(':coach',$coach);
        $reponse1002->execute();
        while($ligne = $reponse1002->fetch(PDO::FETCH_OBJ))
            {
                $mydiv = "mydiv".$i;	$i = $i + 1;
            //	echo $mydiv;
                $nom = htmlentities($ligne->nom);
                $prenom = htmlentities($ligne->prenom);
                $age = htmlentities($ligne->age);
                $taille = htmlentities($ligne->taille);
                $poids = htmlentities($ligne->poids);
                $vma = htmlentities($ligne->vma);
        
            //	echo "$nom $prenom $age $taille $poids $vma";
                $result = $result.
                      "<tr>
                        <th>".$nom."</th>
                        <th>".$prenom."</th>
                        <th>".$age."</th>
                        <th>".$taille."</th>
                        <th>".$poids."</th>
                           <th>".$vma."</th>
                        <th> <div class=\"draggable\" id=".$mydiv." draggable=\"true\" ondrop=\"drop_handler(event);\" ondragstart=\"dragstart_handler(event);\" ondragend=\"dragend_handler(event);\">".$nom." ".$prenom."</div> </th>
                       </tr>";
            }
            return $result;
    }
?>