<?php
function ordreBase($requete)
    {
        $conn = connexionBDD();
        $ordre = "";
        $coach = $_SESSION['pseudo'];

        $couleurNom = "";
        $couleurPoints = "";
        $couleurPasses = "";
        $couleurInterceptions = "";
        $couleurFautes = "";

        if($requete == 'nom')
            {
                $reponse1000 = $conn->prepare("SELECT nom, prenom, nbMatch, tirs, points, passes, passesValide, interceptions, fautes FROM joueur WHERE coach = :coach AND nbMatch != 0 ORDER BY nom ");
                $couleurNom = "bgcolor=\"#FF0000\"";
            }
        if($requete == 'points')
            {
                $reponse1000 = $conn->prepare("SELECT nom, prenom, nbMatch, tirs, points, passes, passesValide, interceptions, fautes FROM joueur WHERE coach = :coach AND nbMatch != 0 ORDER BY points DESC ");
                $couleurPoints = "bgcolor=\"#FF0000\"";
            }
        if($requete == 'passesValide')
            {
                $reponse1000 = $conn->prepare("SELECT nom, prenom, nbMatch, tirs, points, passes, passesValide, interceptions, fautes FROM joueur WHERE coach = :coach AND nbMatch != 0 ORDER BY passesValide DESC ");
                $couleurPasses = "bgcolor=\"#FF0000\"";
            }
        if($requete == 'interceptions')
            {
                $reponse1000 = $conn->prepare("SELECT nom, prenom, nbMatch, tirs, points, passes, passesValide, interceptions, fautes FROM joueur WHERE coach = :coach AND nbMatch != 0 ORDER BY interceptions DESC ");
                $couleurInterceptions = "bgcolor=\"#FF0000\"";
            }
        if($requete == 'fautes')
            {
                $reponse1000 = $conn->prepare("SELECT nom, prenom, nbMatch, tirs, points, passes, passesValide, interceptions, fautes FROM joueur WHERE coach = :coach AND nbMatch != 0 ORDER BY fautes ");
                $couleurFautes = "bgcolor=\"#FF0000\"";
            }
        $reponse1000->bindParam(':coach',$coach);
    //    $reponse1000->bindParam(':requete',$requete);
        $reponse1000->execute();
        while($ligne = $reponse1000->fetch(PDO::FETCH_OBJ))
            {
                $nom = htmlentities($ligne->nom);
                $prenom = htmlentities($ligne->prenom);
                $nbMatch = htmlentities($ligne->nbMatch);
                $tirs = htmlentities($ligne->tirs);
                $points = htmlentities($ligne->points);
                $passes = htmlentities($ligne->passes);
                $passesValide = htmlentities($ligne->passesValide);
                $interceptions = htmlentities($ligne->interceptions);
                $fautes = htmlentities($ligne->fautes);

                $ordre = $ordre.
                    "<tr>
                        <th ".$couleurNom.">".$nom."</th>
                        <th>".$prenom."</th>
                        <th>".$nbMatch."</th>
                        <th>".$tirs."</th>
                        <th ".$couleurPoints.">".$points."</th>
                        <th>".$passes."</th>
                        <th ".$couleurPasses.">".$passesValide."</th>
                        <th ".$couleurInterceptions." >".$interceptions."</th>
                        <th ".$couleurFautes.">".$fautes."</th>
                    </tr>";
            }
        return $ordre;
    }
?>