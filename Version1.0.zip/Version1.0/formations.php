<?php
	function formationHandballBase()
	{
		$placementJoueur = 
				"<div class=\"formation3\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation33\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation331\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>";
		return $placementJoueur;
	}

    function formationBasketBase()
	{
		$placementJoueur = 
				"<div class=\"formation1\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation12\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>

				</div>
				<div class=\"formation122\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>";
		return $placementJoueur;
	}

    function formationFootBase()
	{
		$placementJoueur = 
				"<div class=\"formation4\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation44\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation442\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>
				<div class=\"formation4421\">
					<div class=\"dest_copy\" ondrop=\"drop_handler(event);\" ondragover=\"dragover_handler(event);\"></div>
				</div>";
		return $placementJoueur;
	}
?>