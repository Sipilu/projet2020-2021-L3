<header>

    <figure class="accueilBox">
        <a href="accueil.php"><img id="img_icon" src="image/icon3.png" alt="image lien vers accueil"></a>
    </figure>
    <p class="Text_hearder">Bienvenue sur une application pour faciliter le travail des coachs</p>
    <?php
        if (isset($_SESSION['id']) AND isset($_SESSION['pseudo']))
        {
            echo '<p class="deconnexion">';echo htmlspecialchars($_SESSION['pseudo']);echo '<br><a href="deconnexion.php">Se deconnecter</a></p>';
        }
    ?>

</header>