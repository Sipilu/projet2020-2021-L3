<?php session_start();
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>Accueil</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>
	
    <body>

	<?php
    require_once('header.php');
	?>

	<div class="corpsAccueil">

		<div class="link">
			<a href="connexion.php"><h1>Connexion</h1></a>
			<a href="inscription.php"><h1>Inscription</h1></a>
			<?php
				if (isset($_SESSION['id']) AND isset($_SESSION['pseudo']))
				{
					echo '<a href="deconnexion.php"><h1>Se Deconnecter</h1></a>';
					echo '<a href="Plan_compo_equipe.php"><h1>Plan compo équipe</h1></a>';
				}
			?>
		</div>
		
		<div class="news">
			<p>Le handball est un sport collectif joué à la main où deux équipes de sept joueurs s'affrontent avec un ballon en respectant plusieurs règles sur un terrain rectangulaire de dimensions 40 m par 20 m, séparé en deux camps. L'équipe déclarée victorieuse est celle qui a marqué le plus de buts à la fin du temps imparti, généralement deux périodes de 30 minutes.Aujourd'hui essentiellement disputé dans un gymnase à sept joueurs (six joueurs de champs et un gardien de but), il existe également des versions en extérieur : le handball à onze, version historique disputé sur gazon à onze joueurs jusque dans les années 1960, et le beach handball, disputé sur sable à quatre joueurs et créé au début du xxie siècle.</p>
			<p>Le football est un sport collectif qui se joue avec un ballon sphérique entre deux équipes de onze joueurs. Elles s'opposent sur un terrain rectangulaire délimité, équipé de buts définis sur les largeurs opposées. L'objectif de chaque camp est de mettre le ballon dans le but adverse, sans utiliser les bras, et de le faire plus souvent que l'autre équipe.</p>
			<p>Le basket-ball ou basketball, fréquemment désigné en français par son abréviation basket, est un sport de balle et sport collectif opposant deux équipes de cinq joueurs sur un terrain rectangulaire. L'objectif de chaque équipe est de faire passer un ballon au sein d'un arceau de 46 cm de diamètre, fixé à un panneau et placé à 3,05 m du sol : le panier. Chaque panier inscrit rapporte deux points à son équipe, à l'exception des tirs effectués au-delà de la ligne des trois points qui rapportent trois points et des lancers francs accordés à la suite d'une faute qui rapportent un point. L'équipe avec le nombre de points le plus important remporte la partie.</p>
		</div>

	</div>

	<?php
	require_once('footer.php');
	?>

    </body>	

</html>