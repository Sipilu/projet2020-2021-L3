<footer>
    
    <div class="contact">
        <p>Page par Simon-Pierre Bachelet et Simon Rudent</p>
        <p>
            Contact : <a href="mailto:SimonPierre.Bachelet@etu.uphf.fr"> @Simon-Pierre</a>.<br>
            Contact : <a href="mailto:Simon.Rudent@etu.uphf.fr">@Simon</a>.
        </p>
    </div>

    <div class="social">
        <ul class= "social List">
            <li class= "social List icon"><a class="lienSocial" href="###"><i class="fab fa-facebook-square"></i></a></li>
            <li class= "social List icon"><a class="lienSocial" href="###"><i class="fab fa-instagram-square"></i></a></li>
            <li class= "social List icon"><a class="lienSocial" href="###"><i class="fab fa-twitter-square"></i></a></li>
            <li class= "social List icon"><a class="lienSocial" href="https://github.com/Sipilu/projet2020-2021-L3.git"><i class="fab fa-github-square"></i></a></li>
        </ul>
    </div>

</footer>