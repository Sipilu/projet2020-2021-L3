<?php session_start();
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleFormulaireInscriptionConnexion.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>Inscription</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>

    <body>
	
	<?php
    require_once('header.php');
	?>

		<div class="corps">
			
				<form class="formulaire" action="formulaireInscription.php" method="POST">		  
					<h1 class="titreFormulaire">Inscription</h1>

					<div>
					<label>Mail :</label>			
					<input class="champFormulaire" type="email" name="email" placeholder=" Adresse email" required />
					</div>

					<div>
					<label>Pseudo :</label>	
					<input class="champFormulaire" type="text" name="pseudo" placeholder=" Pseudo" required />
					</div>

					<div>
					<label>mdp :</label>	
					<input class="champFormulaire" type="password" name="password" placeholder=" Mot de passe" required />
					</div>

					<div>
					<label>confirmer mdp:</label>	
					<input class="champFormulaire" type="password" name="passwordConfirm" placeholder=" Mot de passe" required />
					</div>

					<div>
					<button class="boutonValidation bouton1" type="submit">S'inscrire</button>
					</div>

					<p class="redirection">Déjà inscrit?<a href="connexion.php">Connectez-vous ici</a></p>
				</form>

		</div>
		
	<?php
	require_once('footer.php');
	?>
		
    </body>
	
</html>