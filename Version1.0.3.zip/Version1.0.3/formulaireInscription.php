<?php session_start();
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>inscription</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>

	
    <body>
	
	<?php
    require_once('header.php');
	?>

	<div class="corpsAccueil">
		<?php
		//connexion à la base 
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=bddoutilcoach;charset=utf8', 'root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch (Exception $e)
		{
				die("Connection failed: " . mysqli_connect_error());
		}
		// Vérification de la validité des informations
		//protection contre des codes HTML
		$email = htmlspecialchars($_POST['email']);
		$pseudo = htmlspecialchars($_POST['pseudo']);
		
		
		// Verification si le le pseudo ou le mail sont déjà utilisé
		$req = $bdd->prepare("SELECT * FROM coach WHERE email = '$email'");
		$req->execute();
		$resultat = $req->fetchAll();
		$nbresultat = count($resultat);
		$req = $bdd->prepare("SELECT * FROM coach WHERE pseudo = '$pseudo'");
		$req->execute();
		$resultat = $req->fetchAll();
		$nbresultat = $nbresultat + count($resultat);
		if ($nbresultat > 0){     // compte déjà existant
			echo '<p>compte déjà existant utilisant le pseudo '. $pseudo .' ou l\'adresse email '. $email . '</p>';
			echo '<a href="accueil.php"><h1>Page d\'Accueil</h1></a>';
		}
		//Verification mot de passe identique
		else if($_POST['password'] != $_POST['passwordConfirm'])
		{
			echo 'Votre mot de passe doit être identique à votre mot de passe de confirmation';
		}
		else
		{
		// Hachage du mot de passe pour la securité
		$pass_hache = password_hash($_POST['password'], PASSWORD_DEFAULT);
		// Insertion
		
		$req = $bdd->prepare('INSERT INTO coach(pseudo, email, password, date_inscription) VALUES(:pseudo, :email, :password, CURDATE())');
		$req->execute(array(
			'pseudo'=> $pseudo,
			'password' => $pass_hache,
			'email' => $email));
			
		echo '<p>compte crée avec succes</p>';
		echo '<a href="accueil.php"><h1>Page d\'Accueil</h1></a>';
		echo '<a href="connexion.php"><h1>Connexion</h1></a>';
		}
		?>
	</div>
	
	<?php
	require_once('footer.php');
	?>
	
    </body>
	
</html>