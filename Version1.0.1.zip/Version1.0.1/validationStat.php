<?php session_start();
    $tirs = $_POST['tirs'];
    $points = $_POST['points'];
    $passes = $_POST['passes'];
    $passesValide = $_POST['passesValide'];
    $interceptions = $_POST['interceptions'];
    $fautes = $_POST['fautes'];

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $coach = $_SESSION['pseudo'];

    $servername = "localhost";
    $username = "root";
	$password = "";
	$dbname = "bddoutilcoach";
		try{
			$conn = new PDO('mysql:host='.$servername.';dbname='.$dbname,$username,$password);
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			}
		catch(PDOException $e)
    		{
    		echo "Connection failed: " . $e->getMessage();
			}
    if($conn)
        {
            $reponse1000 = $conn->exec("UPDATE joueur SET nbMatch = nbMatch + 1, tirs = tirs + '$tirs', points = points + '$points', passes = passes + '$passes', passesValide = passesValide + '$passesValide', interceptions = interceptions + '$interceptions', fautes = fautes + '$fautes' WHERE nom = '$nom' AND prenom = '$prenom' AND coach = '$coach';");
        }
?>
<!DOCTYPE html>
<html lang="en">

	<head>
	<meta charset="utf-8">
		<link  rel="stylesheet" href="style.css"/>
		<link rel="icon" href="image/logo.png" />
	<title>Page Principal "Statistique"</title>
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
	</head>

	<body>

    <?php
    require_once('header.php');
	?>

    <div class="link">
        <a href="Statistique.php"><h1> Refaire une modification d'un joueur </h1></a>
        <a href="accueil.php"><h1> Revenir a la page d'acceuil </h1></a>
    </div>

    <?php
        if($conn)
            {
                echo "<div> Les statistiques de $nom $prenom ont bien été modifier. </div>";
            }
        else
            {
                echo "<div> ERREUR Les statistiques de $nom $prenom n'ont pas bien été modifier. </div>";
            }
    
	require_once('footer.php');
	?>

  </body>
  
</html>
