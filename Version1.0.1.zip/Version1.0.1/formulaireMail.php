<?php session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>Connexion</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>

    <body>
	
	<?php
    require_once('header.php');
	?>

    <div class="corpsAccueil">
    <p>mail envoyer à :</p>
    <?php
        $destinataire='';
         if(isset($_POST['envoyer']) AND count($_POST['envoyer']) <> 0)
         {
             foreach($_POST['envoyer'] as $element)
             {
                 $destinataire = $destinataire . $element . ',';
             }
                 echo '<p>'. substr($destinataire,0,(strlen($destinataire)-1)).'</p>';
         }
    ?>
    <?php       
    //Le message
    $message=$_POST['Message'];

    // Dans le cas où nos lignes comportent plus de 70 caractères, nous les coupons en utilisant wordwrap()
    $message = wordwrap($message, 70, "\r\n");

    // Envoi du mail
    mail($destinataire,"Convocation", $message);
    ?>
    </div>
    
    <?php
	    require_once('footer.php');
	?>

    </body>	

</html>