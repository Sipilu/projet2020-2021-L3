 <!DOCTYPE html>
 <?php session_start();
	include("connexionBDD.php");
	$conn = connexionBDD();
	$coach = $_SESSION['pseudo'];	
 ?>
<html lang="en">

	<head>
    	<meta charset="utf-8">
		<link  rel="stylesheet" href="style.css"/>
		<link rel="icon" href="image/logo.png" />
   	<title>Page Principal "Statistique"</title>
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
  	</head>

  	<body>

  	<?php
    require_once('header.php');
	?>

  	<!--lien-->
	<div class="link">
		<a href="Plan_Tactique.php"><h1>Plan Tactique</h1></a>
		<a href="Plan_compo_equipe.php"><h1>Plan compo equipe</h1></a>
		<a href="Statistique.php"><h1>Edition joueur</h1></a>
		<a href="Classement.php"><h1>Classement</h1></a>
	</div>

    <form method="post">
		<fieldset>
			<legend><b>Quel est le joueur dont vous voulez modifier ses statistiques ? </b></legend>
			<table border="0" >
			<tr>
				<td>Nom : </td>
				<td><input type="text" name="nom" /></td>
			</tr>
			<tr>
				<td>Prenom : </td>
				<td><input type="text" name="prenom" /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" value="ENVOI" /></td>
			</tr>
			</table>
		</fieldset>
	</form>

	<?php

		if(!empty($_POST['nom']) AND !empty($_POST['prenom'])){

			$nom = $_POST['nom'];
			$prenom = $_POST['prenom'];
			
			$reponse1000 = $conn->prepare("SELECT nom, prenom FROM joueur WHERE nom = :nom AND prenom = :prenom AND coach = :coach ;");
			$reponse1000->bindParam(':nom',$nom);
			$reponse1000->bindParam(':prenom',$prenom);
			$reponse1000->bindParam(':coach',$coach);
			$reponse1000->execute();
			$nbligne = $reponse1000->rowCount();
			if($nbligne == 1)
				{
					?>
					<form action="validationStat.php" method="post">
						<input type="hidden" name="nom" value="<?php echo $nom; ?>" />
						<input type="hidden" name="prenom" value="<?php echo $prenom; ?>" />
						<fieldset>
							<legend><b>Rentrer les informations que vous souhaiteriez ajouter. </b></legend>
							<table border="0" >
							<tr>
								<td>Nombres de tirs effectué : </td>
								<td><input type="text" name="tirs" required></td>
							</tr>
							<tr>
								<td>Nombres de tirs r�ussis : </td>
								<td><input type="text" name="points" required></td>
							</tr>
							<tr>
								<td>Nombres de passes effectu� : </td>
								<td><input type="text" name="passes" required></td>
							</tr>
							<tr>
								<td>Nombres de passes r�ussites : </td>
								<td><input type="text" name="passesValide" required></td>
							</tr>
							<tr>
								<td>Nombres d'interceptions : </td>
								<td><input type="text" name="interceptions" required></td>
							</tr>
							<tr>
								<td>Nombres de fautes commises : </td>
								<td><input type="text" name="fautes" required></td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td><input type="submit" value="ENVOI" /></td>
							</tr>
							</table>
						</fieldset>
					</form>
					<?php
				}
			else
				{
					echo "<div> Aucun joueur ne correspond dans la base de donn�es. </div> </br> <div>Veuillez v�rifier que vous ne vous �tes pas tromp�.</div>";
				}
		}
	?>

	<?php
	require_once('footer.php');
	?>

  </body>
  
</html>
