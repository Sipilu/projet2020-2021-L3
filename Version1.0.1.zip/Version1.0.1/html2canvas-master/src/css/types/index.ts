export type CSSTypes = 'angle' | 'color' | 'image' | 'length' | 'length-percentage';
