<?php 
    session_start();
    include("connexionBDD.php");
    $conn = connexionBDD();
    $coach = $_SESSION['pseudo'];
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="styleSombre.css"/>
		<link rel="stylesheet" href="stylePhone.css"/>
		<link rel="icon" href="image/logo.png" />
        <title>Convocation</title><!-- commentaire -->
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>
    </head>
	
    <body>
    
	<?php
    require_once('header.php');
	?>
    <p>Selectionner les joueurs que vous souhaites convoquer pour le prochain match</p>
	<div class="corps">
    
    <form class="formulaire3" action="formulaireMail.php"method="POST">
    <?php
        echo '<table class="tableMail">';
            echo'<tr><h1 class="titreFormulaire">Liste joueurs</h1></tr>';
            echo'<tr>';
                echo'<th><p>Nom</p></th>';
                echo'<th><p>Prenom</p></th>';
                echo'<th><p>Email</p></th>';
                echo'<th></th>';
            echo'</tr>';

                $req = $conn->prepare("SELECT nom,prenom,email FROM joueur WHERE coach = '$coach'");
                $req->execute();
                $i=1;
                while ($data = $req->fetch()) {
                    echo '<tr>';
                    echo '<th>'.$data['nom'].'</th>';
                    echo '<th>'.$data['prenom'].'</th>';
                    echo '<th>'.$data['email'].'</th>';
                    echo '<th>'. '<input type="checkbox" name="envoyer'.'['. $i . ']' .'" value="'.$data['email'].'" />'.'</th>';
                    echo '</tr>';
                    $i++;
                }
        echo'</table>';
        echo '<textarea class="zoneTexte" type="text" name="Message" required spellcheck></textarea>';
        echo '<button class="boutonValidation2 bouton1" type="submit">Envoyer</button>';
        ?>   
        </form>
	</div>

	<?php
	require_once('footer.php');
	?>

    </body>	

</html>

