<!DOCTYPE html> 
<?php session_start();
    include("ordreClassement.php");
	include("connexionBDD.php");
	$conn = connexionBDD();
	$coach = $_SESSION['pseudo'];	
 ?>
<html lang="en">

	<head>
    	<meta charset="utf-8">
		<link  rel="stylesheet" href="style.css"/>
		<link rel="icon" href="image/logo.png" />
   	<title>Page Principal "Classement"</title>
	<script src="https://kit.fontawesome.com/2e803d93dd.js" crossorigin="anonymous"></script>

    <?php
	if(isset($_POST['Point']))
	{
		$requete = 'points';
        $ordre = ordreBase($requete);
	}
	elseif(isset($_POST['Passe']))
	{
		$requete = 'passesValide';
        $ordre = ordreBase($requete);
	}
	elseif(isset($_POST['Interception']))
	{
		$requete = 'interceptions';
        $ordre = ordreBase($requete);
	}
    elseif(isset($_POST['Faute']))
	{
		$requete = 'fautes';
        $ordre = ordreBase($requete);
	}
    else
    {
        $requete = "nom";
        $ordre = ordreBase($requete);
    }
	?>

  	</head>

  	<body>

  	<?php
    require_once('header.php');
	?>

  	<!--lien-->
	<div class="link">
		<a href="Plan_Tactique.php"><h1>Plan Tactique</h1></a>
		<a href="Plan_compo_equipe.php"><h1>Plan compo equipe</h1></a>
		<a href="Statistique.php"><h1>Edition joueur</h1></a>
		<a href="Classement.php"><h1>Classement</h1></a>
	</div>

        <nav>
			<ul>
				<li class="deroulant">
					<a href="#">Type de classement par &ensp;</a>
					<ul class="sous">
						<li><form method="post"><input type="submit" name="Point" value="Nombre de points marqués"></input></form></li>
						<li><form method="post"><input type="submit" name="Passe" value="Nombre de passes réussites"></input></form></li>
						<li><form method="post"><input type="submit" name="Interception" value="Nombre d'interceptions"></input></form></li>
                        <li><form method="post"><input type="submit" name="Faute" value="Nombre de fautes"></input></form></li>
					</ul>
				</li>
			</ul>
		</nav>



        <table align="center">
				<tr>
					<th colspan="9"> Joueurs </th>
				</tr>
				<tr>
					<th> Nom </th>
					<th> Prenom </th>
					<th> Nombre de match </th>
					<th> Nombre de tirs </th>
					<th> Nombre de tirs marqués </th>
					<th> Nombre de passes </th>
					<th> Nombre de passes réussis </th>
                    <th> Nombre d'interceptions </th>
                    <th> Nombre de fautes </th>
				</tr>
				<?php echo $ordre; ?>


			</table>

    
	<?php
	require_once('footer.php');
	?>

  </body>
  
</html>